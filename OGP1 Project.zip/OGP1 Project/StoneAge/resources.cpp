#include "resources.h"

//QString resourceToText(Resource value){
//    switch((int)value){
//    case(2):
//        return "food";
//    case(3):
//        return "wood";
//    case(4):
//        return "clay";
//    case(5):
//        return "stone";
//    case(6):
//        return "gold";
//    default:
//        return "";
//    }
//}
