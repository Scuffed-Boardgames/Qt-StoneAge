// Denzell Mgbokwere 2054872
#ifndef RESOURCES_H
#define RESOURCES_H


enum class Resource { // an enumerator where each resource is their value
    food = 2,
    wood = 3,
    clay = 4,
    stone = 5,
    gold = 6
};

#endif // RESOURCES_H
