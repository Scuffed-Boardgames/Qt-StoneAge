// Denzell Mgbokwere 2054872
#ifndef COLOUR_H
#define COLOUR_H

enum class Colour {
    none = -1,
    red = 0,
    blue = 1,
    yellow = 2,
    green = 3
};

#endif // COLOUR_H
